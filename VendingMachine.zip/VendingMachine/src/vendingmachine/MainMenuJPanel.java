package vendingmachine;

import java.awt.BorderLayout;
import java.awt.Container;

public class MainMenuJPanel extends javax.swing.JFrame {

    private MainFrame mainFrame;
    private DrinkJPanel drinkJPanel;
    private FoodJPanel foodJPanel;
    private MiscellaneousJPanel miscJPanel;
     
    public MainMenuJPanel() {
        initComponents();
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }

    public void setMainFrame(MainFrame mainFrame){
        this.mainFrame = mainFrame;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        mainMenuJPanel = new javax.swing.JPanel();
        vendingMachine = new javax.swing.JLabel();
        drinkToggleButton = new javax.swing.JToggleButton();
        foodToggleButton = new javax.swing.JToggleButton();
        miscellaneousToggleButton = new javax.swing.JToggleButton();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        mainMenuJPanel.setBackground(new java.awt.Color(255, 51, 51));
        mainMenuJPanel.setForeground(new java.awt.Color(255, 0, 51));
        mainMenuJPanel.setPreferredSize(new java.awt.Dimension(450, 150));

        vendingMachine.setFont(new java.awt.Font("Tahoma", 1, 46)); // NOI18N
        vendingMachine.setText("Vending  Machine");

        drinkToggleButton.setText("Drink");
        drinkToggleButton.setPreferredSize(new java.awt.Dimension(101, 23));
        drinkToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinkToggleButtonActionPerformed(evt);
            }
        });

        foodToggleButton.setText("Food");
        foodToggleButton.setPreferredSize(new java.awt.Dimension(101, 23));
        foodToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                foodToggleButtonActionPerformed(evt);
            }
        });

        miscellaneousToggleButton.setText("Miscellaneous");
        miscellaneousToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miscellaneousToggleButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainMenuJPanelLayout = new javax.swing.GroupLayout(mainMenuJPanel);
        mainMenuJPanel.setLayout(mainMenuJPanelLayout);
        mainMenuJPanelLayout.setHorizontalGroup(
            mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                        .addComponent(foodToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                        .addComponent(drinkToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(miscellaneousToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(vendingMachine))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        mainMenuJPanelLayout.setVerticalGroup(
            mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(vendingMachine)
                .addGap(18, 18, 18)
                .addGroup(mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(foodToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(drinkToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(miscellaneousToggleButton))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(mainMenuJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(mainMenuJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void drinkToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinkToggleButtonActionPerformed
    
        initComponents();
        drinkJPanel = new DrinkJPanel();
        this.drinkJPanel.setMainFrame(this);
        Container drinkPane = (Container) this.getContentPane();
        drinkPane.add(this.drinkJPanel, BorderLayout.CENTER);
        
    }//GEN-LAST:event_drinkToggleButtonActionPerformed

    private void foodToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_foodToggleButtonActionPerformed
       
        initComponents();
        foodJPanel = new FoodJPanel();
        this.foodJPanel.setMainFrame(this);
        Container foodPane = (Container) this.getContentPane();
        foodPane.add(this.foodJPanel, BorderLayout.CENTER);
    }//GEN-LAST:event_foodToggleButtonActionPerformed

    private void miscellaneousToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miscellaneousToggleButtonActionPerformed
       
        initComponents();
        miscJPanel = new MiscellaneousJPanel();
        this.miscJPanel.setMainFrame(this);
        Container miscPane = (Container) this.getContentPane();
        miscPane.add(this.miscJPanel, BorderLayout.CENTER);
    }//GEN-LAST:event_miscellaneousToggleButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton drinkToggleButton;
    private javax.swing.JToggleButton foodToggleButton;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel mainMenuJPanel;
    private javax.swing.JToggleButton miscellaneousToggleButton;
    private javax.swing.JLabel vendingMachine;
    // End of variables declaration//GEN-END:variables


}
