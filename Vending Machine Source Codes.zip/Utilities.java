package vendingmachine;

public class Utilities {
    
    
}
