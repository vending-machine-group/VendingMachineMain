package vendingmachine;
import java.util.ArrayList;
import java.util.List;


public class VendingMachine {

    public static void main(String[] args) {
        
        
    }
    
}
