package vendingmachine;

import java.awt.BorderLayout;
import java.awt.Container;

public class MainMenuJFrame extends javax.swing.JFrame {

    private MainFrameJFrame mainFrameFrame;
    private DrinkJPanel drinkJPanel;
    private FoodJPanel foodJPanel;
    private MiscellaneousJPanel miscJPanel;
    private MainFrame mainFrame;
     
    public MainMenuJFrame() {
        initComponents();
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }

    public void setMainFrame(MainFrame mainFrame){
        this.mainFrame = mainFrame;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        mainMenuJPanel = new javax.swing.JPanel();
        vendingMachine = new javax.swing.JLabel();
        drinkToggleButton = new javax.swing.JToggleButton();
        foodToggleButton = new javax.swing.JToggleButton();
        miscellaneousToggleButton = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        mainMenuJPanel.setBackground(new java.awt.Color(255, 51, 51));
        mainMenuJPanel.setForeground(new java.awt.Color(255, 0, 51));
        mainMenuJPanel.setPreferredSize(new java.awt.Dimension(450, 150));

        vendingMachine.setFont(new java.awt.Font("Tahoma", 1, 46)); // NOI18N
        vendingMachine.setText("Vending  Machine");

        drinkToggleButton.setText("Drink");
        drinkToggleButton.setPreferredSize(new java.awt.Dimension(101, 23));
        drinkToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinkToggleButtonActionPerformed(evt);
            }
        });

        foodToggleButton.setText("Food");
        foodToggleButton.setPreferredSize(new java.awt.Dimension(101, 23));
        foodToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                foodToggleButtonActionPerformed(evt);
            }
        });

        miscellaneousToggleButton.setText("Miscellaneous");
        miscellaneousToggleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miscellaneousToggleButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainMenuJPanelLayout = new javax.swing.GroupLayout(mainMenuJPanel);
        mainMenuJPanel.setLayout(mainMenuJPanelLayout);
        mainMenuJPanelLayout.setHorizontalGroup(
            mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                        .addComponent(foodToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                        .addComponent(drinkToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(miscellaneousToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(vendingMachine))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        mainMenuJPanelLayout.setVerticalGroup(
            mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuJPanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(vendingMachine)
                .addGap(18, 18, 18)
                .addGroup(mainMenuJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(foodToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(drinkToggleButton, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(miscellaneousToggleButton))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(mainMenuJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(mainMenuJPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 450, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 150, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void drinkToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinkToggleButtonActionPerformed

        initComponents();
        drinkJPanel = new DrinkJPanel();
        this.drinkJPanel.setMainFrame();
        Container drinkPane = (Container) this.getContentPane();
        drinkPane.add(this.drinkJPanel, BorderLayout.CENTER);

    }//GEN-LAST:event_drinkToggleButtonActionPerformed

    private void foodToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_foodToggleButtonActionPerformed

        initComponents();
        foodJPanel = new FoodJPanel();
        this.foodJPanel.setMainFrame();
        Container foodPane = (Container) this.getContentPane();
        foodPane.add(this.foodJPanel, BorderLayout.CENTER);
    }//GEN-LAST:event_foodToggleButtonActionPerformed

    private void miscellaneousToggleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miscellaneousToggleButtonActionPerformed

        initComponents();
        miscJPanel = new MiscellaneousJPanel();
        this.miscJPanel.setMainFrame();
        Container miscPane = (Container) this.getContentPane();
        miscPane.add(this.miscJPanel, BorderLayout.CENTER);
    }//GEN-LAST:event_miscellaneousToggleButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenuJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenuJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenuJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenuJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainMenuJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton drinkToggleButton;
    private javax.swing.JToggleButton foodToggleButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel mainMenuJPanel;
    private javax.swing.JToggleButton miscellaneousToggleButton;
    private javax.swing.JLabel vendingMachine;
    // End of variables declaration//GEN-END:variables
}
