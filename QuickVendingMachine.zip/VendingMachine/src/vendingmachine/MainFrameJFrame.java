package vendingmachine;

class MainFrameJFrame {
    
}
