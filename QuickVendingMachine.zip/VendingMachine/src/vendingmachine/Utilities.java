package vendingmachine;

public class Utilities {
    
    private Double Price;
    private Double Cash;
    private Double Change;
 
    public Boolean makePurchase(double cash){
 //       this.Cash+=Cash;
    Boolean success = false;

        if(Cash>=Price){
        Change=Cash-Price;
        success = true;}
    return success;
    }
    public void setCash(Double Cash) {
        this.Cash+=Cash;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double Price) {
        this.Price = Price;
    }

    public Double getChange() {
        return Change;
    }
    
}